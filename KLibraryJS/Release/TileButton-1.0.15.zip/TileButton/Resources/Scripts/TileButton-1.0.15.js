﻿/*
* TileButton 1.0.15
* Copyright © 2012, Keiho Sakapon.
*/

(function ($) {
    $.fn.tileButton = function (bodyForeColor, bodyBackColor, accentColor) {
        /// <summary>
        ///     子孫要素にタイル ボタンを設定します。
        /// </summary>
        /// <param name="bodyForeColor" type="String">ページの前景色。</param>
        /// <param name="bodyBackColor" type="String">ページの背景色。</param>
        /// <param name="accentColor" type="String">アクセント カラー。</param>
        /// <returns type="jQuery" />

        bodyForeColor = $.getCookie("TileBodyForeColor", bodyForeColor);
        bodyBackColor = $.getCookie("TileBodyBackColor", bodyBackColor);
        accentColor = $.getCookie("TileAccentColor", accentColor);

        $.setCssRules("TileBodyColorStyle",
            $.format("body { color: {0}; background-color: {1}; }", bodyForeColor, bodyBackColor),
            $.format(".tile-text, .tile-image, .tile-body-color, .tile-accent-color { border-color: {0}; }", bodyBackColor));
        $.setCssRules("TileAccentColorStyle",
            $.format(".tile-text, .tile-image, .tile-body-color, .tile-accent-color { background-color: {0}; }", accentColor));
        this.find(".tile-body-color")
            .click(function () {
                $.setCssRules("TileBodyColorStyle",
                    $.format("body { color: {0}; background-color: {1}; }", $(this).data("foreColor"), $(this).data("backColor")),
                    $.format(".tile-text, .tile-image, .tile-body-color, .tile-accent-color { border-color: {0}; }", $(this).data("backColor")));
                $.setCookie("TileBodyForeColor", $(this).data("foreColor"));
                $.setCookie("TileBodyBackColor", $(this).data("backColor"));
            });
        this.find(".tile-accent-color")
            .click(function () {
                $.setCssRules("TileAccentColorStyle",
                    $.format(".tile-text, .tile-image, .tile-body-color, .tile-accent-color { background-color: {0}; }", $(this).css("background-color")));
                $.setCookie("TileAccentColor", $(this).css("background-color"));
            });
        this.find(".tile-text").setViewStates("tile-text-pressed", 0.55);
        this.find(".tile-image").setViewStates("tile-image-pressed", 0.55);
        this.find(".tile-body-color").setViewStates("tile-body-color-pressed", 0.55);
        this.find(".tile-accent-color").setViewStates("tile-accent-color-pressed", 0.55);
        return this;
    };

    $.fn.setViewStates = function (activeClass, focusOpacity) {
        /// <summary>
        ///     表示状態を設定します。
        /// </summary>
        /// <param name="activeClass" type="String">アクティブ状態に適用するクラスの名前。</param>
        /// <param name="focusOpacity" type="String">フォーカスまたはホバー状態に適用する不透明度。</param>
        /// <returns type="jQuery" />

        this
            .focusin(function () { $(this).fadeTo(0, focusOpacity); })
            .focusout(function () { $(this).fadeTo(0, 1).removeClass(activeClass); })
            .mouseover(function () { $(this).fadeTo(0, focusOpacity); })
            .mouseout(function () { $(this).fadeTo(0, 1).removeClass(activeClass); })
            .mousedown(function () { $(this).fadeTo(0, 1).addClass(activeClass); })
            .mouseup(function () { $(this).fadeTo(0, focusOpacity).removeClass(activeClass); })
            .keydown(function (e) { if (e.keyCode == 13 || this.tagName.toUpperCase() != "A" && e.keyCode == 32) $(this).fadeTo(0, 1).addClass(activeClass); })
            .keyup(function (e) { if (e.keyCode == 13 || this.tagName.toUpperCase() != "A" && e.keyCode == 32) $(this).fadeTo(0, focusOpacity).removeClass(activeClass); })
            ;
        return this;
    };

    $.fn.setIsEnabled = function (isEnabled) {
        /// <summary>
        ///     要素の状態を、有効または無効に設定します。
        /// </summary>
        /// <param name="isEnabled" type="Boolean">要素が有効であるかどうかを示す値。</param>
        /// <returns type="jQuery" />

        if (isEnabled) {
            this.removeAttr("disabled");
        } else {
            this.attr("disabled", "disabled");
        }
        return this;
    };

    $.setCssRules = function (styleId, cssRules) {
        /// <summary>
        ///     CSS のルールを head 要素に設定します。
        /// </summary>
        /// <param name="styleId" type="String">スタイルの ID。</param>
        /// <param name="cssRules" type="String">CSS のルール。可変長パラメーターです。</param>

        $("#" + styleId).remove();
        var styleSheet = $("<style></style>")
            .attr("id", styleId)
            .attr("type", "text/css")
            .appendTo("head")[0].sheet;
        // TODO: IE8 以下の場合。
        if (!styleSheet) return;
        for (var i = 1; i < arguments.length; i++) {
            styleSheet.insertRule(arguments[i], i - 1);
        }
    };

    $.getCookie = function (key, defaultValue) {
        /// <summary>
        ///     Cookie から、指定されたキーに対応する値を取得します。
        /// </summary>
        /// <param name="key" type="String">キー。</param>
        /// <param name="defaultValue" type="String">既定値。</param>
        /// <returns type="String" />

        if (!document.cookie) {
            return defaultValue;
        }
        var entries = document.cookie.split("; ");
        for (var i = 0; i < entries.length; i++) {
            var pair = entries[i].split("=");
            if (pair[0] == key) {
                return unescape(pair[1]);
            }
        }
        return defaultValue;
    };

    $.setCookie = function (key, value) {
        /// <summary>
        ///     Cookie に、キーと値のペアを格納します。
        ///     有効期限を 365 日後に設定します。
        /// </summary>
        /// <param name="key" type="String">キー。</param>
        /// <param name="value" type="String">値。</param>

        var expired = new Date();
        expired.setTime(expired.getTime() + 365 * 24 * 60 * 60 * 1000);
        document.cookie = $.format("{0}={1}; expires={2};", key, escape(value), expired.toGMTString());
    };

    $.format = function (fmt, args) {
        /// <summary>
        ///     指定された書式を利用して、文字列を置換します。
        /// </summary>
        /// <param name="fmt" type="String">書式。</param>
        /// <param name="args" type="String">置換後の文字列。可変長パラメーターです。</param>
        /// <returns type="String" />

        for (var i = 1; i < arguments.length; i++) {
            var reg = new RegExp("\\{" + (i - 1) + "\\}", "g")
            fmt = fmt.replace(reg, arguments[i]);
        }
        return fmt;
    };
})(jQuery);
